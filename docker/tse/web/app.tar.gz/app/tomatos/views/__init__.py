from .IndexView import IndexView
from .DetailView import DetailView
from .BaseView import BaseView