from django.apps import AppConfig


class TomatosConfig(AppConfig):
    name = 'tomatos'
